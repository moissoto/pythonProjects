from setuptools import setup

setup(
    name='vsearch',
    version='1.0',
    description='The Head First Python Search Tools',
    author = 'Moisés Soto Córdova',
    author_email='moissoto@gmail.com',
    url='headfirstñabs.com',
    py_modules = ['vsearch'],
)

